from django.db import models

# Create your models here.
class Corona(models.Model):
    corona_per = models.CharField(max_length=10000)
    corona_way = models.CharField(max_length=10000)
    corona_date = models.CharField(max_length=10000)
    corona_peo = models.CharField(max_length=10000)
    corona_hos = models.CharField(max_length=10000)

    def __str__(self):
        return self.corona_per

# from django.db import models
#
# # Create your models here.
# class Corona(models.Model):
#     corona_num = models.CharField(max_length=10000)
#     corona_per = models.CharField(max_length=10000)
#     corona_way = models.CharField(max_length=10000)
#     corona_date = models.CharField(max_length=10000)
#     corona_hos = models.CharField(max_length=10000)
#     corona_peo = models.CharField(max_length=10000)
#
#     def __str__(self):
#         return self.corona_num