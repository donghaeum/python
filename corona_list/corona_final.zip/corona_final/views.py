from django.shortcuts import render
from django.http import HttpResponse
from .corona_info import coronaCR
from .models import Corona
from django.http import JsonResponse
# from django.views.generic import ListView

# Create your views here.
def all_corona(request):
    coronaCR()
    return HttpResponse("코로나 바이러스 확진자 정보")

def corona_list(request):
    corona_all = Corona.objects.all()
    corona_list = []
    for corona in corona_all:
        corona_list.append({
            "per_info": corona.corona_per,
            "route": corona.corona_way,
            "date": corona.corona_date,
            "hospital": corona.corona_hos,
            "contacts": corona.corona_peo
        })

    return JsonResponse(corona_list, safe=False)

# class Index(ListView):
#     model = Corona
#     paginate_by = 10

# from django.shortcuts import render
# from django.http import HttpResponse
# from .corona_info import pageAll
# from .models import Corona
# from django.http import JsonResponse
# from django.views.generic import ListView
#
# # Create your views here.
# def all_corona(request):
#     pageAll()
#     return HttpResponse("코로나 바이러스 확진자 정보")
#
# def corona_list(request):
#     corona_all = Corona.objects.all()
#     corona_list = []
#     for corona in corona_all:
#         corona_list.append({
#             "num": corona.corona_num,
#             "per_info": corona.corona_per,
#             "route": corona.corona_way,
#             "date": corona.corona_date,
#             "hospital": corona.corona_hos,
#             "contacts": corona.corona_peo
#         })
#
#     return JsonResponse(corona_list, safe=False)
#
# class Index(ListView):
#     model = Corona
#     paginate_by = 10