from pandas.io.parsers import read_csv
import matplotlib.pyplot as plt
from matplotlib import font_manager, rc

df = read_csv('corona_list.csv')

print('Shape', df.shape)
print('Head:\n', df.head(3))
print('Desecribe:\n', df.describe())

font_name = font_manager.FontProperties(fname="c:/Windows/Fonts/malgun.ttf").get_name()
rc('font', family=font_name)

plt.scatter(df.date, df.per_info)
plt.xlabel('count')
plt.ylabel('date')
plt.show()

