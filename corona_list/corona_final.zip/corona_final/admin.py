from django.contrib import admin
from .models import Corona

# Register your models here.
admin.site.register(Corona)