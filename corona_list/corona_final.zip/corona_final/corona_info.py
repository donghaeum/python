# 서울시 사이트에서 크롤링
import requests
import bs4
from .models import Corona

def coronaCR():
    html = requests.get('http://news.seoul.go.kr/welfare/wp-content/plugins/seoul-scrap/print-pop.php?post_id=513105&parent_id=http://news.seoul.go.kr/welfare/archives/513105&location_html=')
    html_soup = bs4.BeautifulSoup(html.text, 'html.parser')
    corona_all_list = html_soup.findAll('tr', {'class':'patient'})

    for corona in corona_all_list:
        corona_all_info = corona.findAll('td')
        coronaModel = Corona()
        coronaModel.corona_per = corona_all_info[3].text
        coronaModel.corona_way = corona_all_info[4].text
        coronaModel.corona_date = corona_all_info[5].text
        coronaModel.corona_peo = corona_all_info[6].text
        coronaModel.corona_hos = corona_all_info[7].text
        coronaModel.save()

    # print('인적 사항 :' + corona_all_info[3].text)
    # print('감염 경로 :' + corona_all_info[4].text)
    # print('확진일 :' + corona_all_info[5].text)
    # print('접촉 :' + corona_all_info[6].text)
    # print('격리 시설 :' + corona_all_info[7].text)
    # print('접촉자 수 :' + corona_all_info[8].text)

# 질병 관리 본부 사이트에서 크롤링

# import requests
# import bs4
# from .models import Corona
#
# # print(page())
#
# # data = {'pageIndex': 'page()'}
#
# def coronaCR(page):
#     html = requests.post('http://ncov.mohw.go.kr/bdBoardList.do?brdId=1&brdGubun=12&pageIndex='+page)
#
# # print(html.text)
#     html_soup = bs4.BeautifulSoup(html.text, 'html.parser')
#     corona_all_list = html_soup.find('div', {'class':'in_list'})
#     corona_list = corona_all_list.findAll('ul')
#
#     try:
#         for corona in corona_list:
#             corona_all_info = corona.findAll('span')
#             coronaModel = Corona()
#             coronaModel.corona_num = corona_all_info[1].text
#             coronaModel.corona_per = corona_all_info[3].text
#             coronaModel.corona_way = corona_all_info[5].text
#             coronaModel.corona_date = "".join(corona_all_info[7].text.split())
#             coronaModel.corona_hos = corona_all_info[9].text
#             coronaModel.corona_peo = " ".join(corona_all_info[11].text.split())
#             coronaModel.save()
#
#     except IndexError:
#         pass
#
#         # print('환자 번호 :' + corona_all_info[1].text)
#         # print('인적 사항 :' + corona_all_info[3].text)
#         # print('감염 경로 :' + corona_all_info[5].text)
#         # print('확진 일자 :' + "".join(corona_all_info[7].text.split()))
#         # print('입원 기관 :' + corona_all_info[9].text)
#         # print('접촉자 수 :' + " ".join(corona_all_info[11].text.split()))
#
# def pageAll():
#     pages = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
#     for all_page in pages:
#         coronaCR(all_page)
#
# # print(html.status_code)
# # print(html.text)
#
# # sentence = ' hello  apple'
# # " ".join(sentence.split())  # 'hello apple'