from django.urls import path
from .views import *

urlpatterns = [
    path('corona_info/', all_corona, name='corona_info'),
    path('api/corona/', corona_list, name='corona')
]