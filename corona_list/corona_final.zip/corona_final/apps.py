from django.apps import AppConfig


class CoronaFinalConfig(AppConfig):
    name = 'corona_final'
